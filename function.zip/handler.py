import pymysql

endpoint = 'aws-experiments.cggslfjqqytx.us-east-1.rds.amazonaws.com'
username = 'admin'
password = 'root1234'
database = 'Transactions_Prod'
connection = pymysql.connect(
    endpoint, user=username, passwd=password, db=database)


def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute('select * from transactions')
    rows = cursor.fetchall()

    for row in rows:
        print("{0} {1} {2}".format(rows[0], row[1], row[2]))
